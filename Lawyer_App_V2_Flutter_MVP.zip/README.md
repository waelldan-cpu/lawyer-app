# Lawyer App V2 — Flutter MVP

نسخة أولية قابلة للتشغيل على Android.

## التشغيل
1. ثبّت Flutter وAndroid Studio.
2. افتح مجلد المشروع.
3. نفّذ:
   flutter pub get
   flutter run

## إنشاء APK
flutter build apk --release

النسخة الحالية تحفظ القضايا والعملاء والمواعيد محلياً باستخدام SharedPreferences.
المساعد القانوني حالياً واجهة تجريبية، وسيتم ربطه لاحقاً بواجهة ذكاء اصطناعي وقاعدة القوانين السورية.
