import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(LawyerApp(store: store));
}

class CaseItem {
  String id, title, client, court, status, notes;
  CaseItem({required this.id, required this.title, required this.client, required this.court, required this.status, required this.notes});
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'client':client,'court':court,'status':status,'notes':notes};
  factory CaseItem.fromJson(Map<String,dynamic> j)=>CaseItem(id:j['id'],title:j['title'],client:j['client'],court:j['court'],status:j['status'],notes:j['notes']);
}
class ClientItem {
  String id,name,phone,notes;
  ClientItem({required this.id,required this.name,required this.phone,required this.notes});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'phone':phone,'notes':notes};
  factory ClientItem.fromJson(Map<String,dynamic> j)=>ClientItem(id:j['id'],name:j['name'],phone:j['phone'],notes:j['notes']);
}
class Appointment {
  String id,title,date,time,notes;
  Appointment({required this.id,required this.title,required this.date,required this.time,required this.notes});
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'date':date,'time':time,'notes':notes};
  factory Appointment.fromJson(Map<String,dynamic> j)=>Appointment(id:j['id'],title:j['title'],date:j['date'],time:j['time'],notes:j['notes']);
}

class AppStore extends ChangeNotifier {
  List<CaseItem> cases=[]; List<ClientItem> clients=[]; List<Appointment> appointments=[];
  Future<void> load() async {
    final p=await SharedPreferences.getInstance();
    cases=(jsonDecode(p.getString('cases')??'[]') as List).map((e)=>CaseItem.fromJson(e)).toList();
    clients=(jsonDecode(p.getString('clients')??'[]') as List).map((e)=>ClientItem.fromJson(e)).toList();
    appointments=(jsonDecode(p.getString('appointments')??'[]') as List).map((e)=>Appointment.fromJson(e)).toList();
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    await p.setString('cases',jsonEncode(cases.map((e)=>e.toJson()).toList()));
    await p.setString('clients',jsonEncode(clients.map((e)=>e.toJson()).toList()));
    await p.setString('appointments',jsonEncode(appointments.map((e)=>e.toJson()).toList()));
    notifyListeners();
  }
  String id()=>DateTime.now().microsecondsSinceEpoch.toString();
}

class LawyerApp extends StatelessWidget {
  final AppStore store;
  const LawyerApp({super.key,required this.store});
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:store,builder:(_,__)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'المحامي',
    theme:ThemeData(useMaterial3:true,colorSchemeSeed:Colors.indigo,fontFamily:'Arial'),
    home:HomePage(store:store),
  ));
}

class HomePage extends StatefulWidget {
  final AppStore store; const HomePage({super.key,required this.store});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage>{
  int index=0;
  @override Widget build(BuildContext c){
    final pages=[
      Dashboard(store:widget.store),
      CasesPage(store:widget.store),
      ClientsPage(store:widget.store),
      AppointmentsPage(store:widget.store),
      AssistantPage(),
      SettingsPage(store:widget.store)
    ];
    return Directionality(textDirection:TextDirection.rtl,child:Scaffold(
      appBar:AppBar(title:Text(['الرئيسية','القضايا','العملاء','المواعيد','المساعد القانوني','الإعدادات'][index])),
      body:pages[index],
      bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(i)=>setState(()=>index=i),destinations:const[
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'الرئيسية'),
        NavigationDestination(icon:Icon(Icons.gavel),label:'القضايا'),
        NavigationDestination(icon:Icon(Icons.people_outline),label:'العملاء'),
        NavigationDestination(icon:Icon(Icons.event),label:'المواعيد'),
        NavigationDestination(icon:Icon(Icons.smart_toy_outlined),label:'المساعد'),
      ]),
    ));
  }
}

class Dashboard extends StatelessWidget{
  final AppStore store; const Dashboard({super.key,required this.store});
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('مكتب المحاماة',style:TextStyle(fontSize:26,fontWeight:FontWeight.bold)),
      const SizedBox(height:8),const Text('إدارة القضايا والعملاء والمواعيد من مكان واحد.'),
    ]))),
    const SizedBox(height:12),
    Row(children:[
      Expanded(child:_stat('القضايا',store.cases.length,Icons.gavel)),
      Expanded(child:_stat('العملاء',store.clients.length,Icons.people)),
      Expanded(child:_stat('المواعيد',store.appointments.length,Icons.event)),
    ]),
  ]);
  Widget _stat(String t,int n,IconData i)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(children:[Icon(i),Text('$n',style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(t)])));
}

class CasesPage extends StatelessWidget{
  final AppStore store; const CasesPage({super.key,required this.store});
  @override Widget build(BuildContext c)=>_CrudPage(title:'القضايا',empty:'لا توجد قضايا بعد',items:store.cases.map((x)=>ListTile(title:Text(x.title),subtitle:Text('${x.client} • ${x.court}\\n${x.status}'),isThreeLine:true,leading:const Icon(Icons.folder),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{store.cases.removeWhere((e)=>e.id==x.id);await store.save();}))).toList(),onAdd:()=>showDialog(context:c,builder:(_)=>CaseDialog(store:store)));
}
class ClientsPage extends StatelessWidget{
  final AppStore store; const ClientsPage({super.key,required this.store});
  @override Widget build(BuildContext c)=>_CrudPage(title:'العملاء',empty:'لا يوجد عملاء بعد',items:store.clients.map((x)=>ListTile(title:Text(x.name),subtitle:Text(x.phone),leading:const Icon(Icons.person),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{store.clients.removeWhere((e)=>e.id==x.id);await store.save();}))).toList(),onAdd:()=>showDialog(context:c,builder:(_)=>ClientDialog(store:store)));
}
class AppointmentsPage extends StatelessWidget{
  final AppStore store; const AppointmentsPage({super.key,required this.store});
  @override Widget build(BuildContext c)=>_CrudPage(title:'المواعيد',empty:'لا توجد مواعيد بعد',items:store.appointments.map((x)=>ListTile(title:Text(x.title),subtitle:Text('${x.date} • ${x.time}'),leading:const Icon(Icons.event),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{store.appointments.removeWhere((e)=>e.id==x.id);await store.save();}))).toList(),onAdd:()=>showDialog(context:c,builder:(_)=>AppointmentDialog(store:store)));
}
class _CrudPage extends StatelessWidget{
  final String title,empty; final List<Widget> items; final VoidCallback onAdd;
  const _CrudPage({required this.title,required this.empty,required this.items,required this.onAdd});
  @override Widget build(BuildContext c)=>Scaffold(body:items.isEmpty?Center(child:Text(empty)):ListView(children:items),floatingActionButton:FloatingActionButton(onPressed:onAdd,child:const Icon(Icons.add)));
}

class CaseDialog extends StatefulWidget{final AppStore store;const CaseDialog({super.key,required this.store});@override State<CaseDialog>createState()=>_CaseDialogState();}
class _CaseDialogState extends State<CaseDialog>{final a=TextEditingController(),b=TextEditingController(),d=TextEditingController(),e=TextEditingController();String status='مفتوحة';
@override Widget build(BuildContext c)=>AlertDialog(title:const Text('إضافة قضية'),content:SingleChildScrollView(child:Column(children:[TextField(controller:a,decoration:const InputDecoration(labelText:'عنوان القضية')),TextField(controller:b,decoration:const InputDecoration(labelText:'اسم العميل')),TextField(controller:d,decoration:const InputDecoration(labelText:'المحكمة')),DropdownButtonFormField(value:status,items:['مفتوحة','مؤجلة','مغلقة'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(x)=>setState(()=>status=x!),decoration:const InputDecoration(labelText:'الحالة')),TextField(controller:e,decoration:const InputDecoration(labelText:'ملاحظات'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{widget.store.cases.add(CaseItem(id:widget.store.id(),title:a.text,client:b.text,court:d.text,status:status,notes:e.text));await widget.store.save();if(c.mounted)Navigator.pop(c);},child:const Text('حفظ'))]);}
class ClientDialog extends StatefulWidget{final AppStore store;const ClientDialog({super.key,required this.store});@override State<ClientDialog>createState()=>_ClientDialogState();}
class _ClientDialogState extends State<ClientDialog>{final a=TextEditingController(),b=TextEditingController(),d=TextEditingController();@override Widget build(BuildContext c)=>AlertDialog(title:const Text('إضافة عميل'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:a,decoration:const InputDecoration(labelText:'الاسم')),TextField(controller:b,decoration:const InputDecoration(labelText:'الهاتف')),TextField(controller:d,decoration:const InputDecoration(labelText:'ملاحظات'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{widget.store.clients.add(ClientItem(id:widget.store.id(),name:a.text,phone:b.text,notes:d.text));await widget.store.save();if(c.mounted)Navigator.pop(c);},child:const Text('حفظ'))]);}
class AppointmentDialog extends StatefulWidget{final AppStore store;const AppointmentDialog({super.key,required this.store});@override State<AppointmentDialog>createState()=>_AppointmentDialogState();}
class _AppointmentDialogState extends State<AppointmentDialog>{final a=TextEditingController(),b=TextEditingController(),d=TextEditingController(),e=TextEditingController();@override Widget build(BuildContext c)=>AlertDialog(title:const Text('إضافة موعد'),content:SingleChildScrollView(child:Column(children:[TextField(controller:a,decoration:const InputDecoration(labelText:'عنوان الموعد')),TextField(controller:b,decoration:const InputDecoration(labelText:'التاريخ')),TextField(controller:d,decoration:const InputDecoration(labelText:'الوقت')),TextField(controller:e,decoration:const InputDecoration(labelText:'ملاحظات'))])),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('إلغاء')),FilledButton(onPressed:()async{widget.store.appointments.add(Appointment(id:widget.store.id(),title:a.text,date:b.text,time:d.text,notes:e.text));await widget.store.save();if(c.mounted)Navigator.pop(c);},child:const Text('حفظ'))]);}

class AssistantPage extends StatefulWidget{const AssistantPage({super.key});@override State<AssistantPage>createState()=>_AssistantPageState();}
class _AssistantPageState extends State<AssistantPage>{final q=TextEditingController();String answer='مرحباً. أنا المساعد القانوني. اكتب سؤالك القانوني هنا.';@override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(16),child:Column(children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Text(answer))),const Spacer(),TextField(controller:q,minLines:2,maxLines:4,decoration:const InputDecoration(border:OutlineInputBorder(),hintText:'اكتب السؤال القانوني...')),const SizedBox(height:8),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:(){setState(()=>answer='تم استلام سؤالك: ${q.text}\\n\\nهذه نسخة تجريبية. في المرحلة التالية سنربطها بواجهة ذكاء اصطناعي وقاعدة القوانين السورية.');},icon:const Icon(Icons.send),label:const Text('إرسال')))]));}

class SettingsPage extends StatelessWidget{final AppStore store;const SettingsPage({super.key,required this.store});@override Widget build(BuildContext c)=>ListView(children:[const ListTile(leading:Icon(Icons.language),title:Text('اللغة'),subtitle:Text('العربية')),const ListTile(leading:Icon(Icons.storage),title:Text('التخزين'),subtitle:Text('البيانات محفوظة محلياً على الجهاز')),ListTile(leading:const Icon(Icons.delete_forever),title:const Text('حذف جميع البيانات'),onTap:()async{store.cases.clear();store.clients.clear();store.appointments.clear();await store.save();})]);}
